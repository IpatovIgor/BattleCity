import pygame


class Brick_bloc:
    def __init__(self, x, y):
        self.X = x
        self.Y = y
        self.Rectangle = self.Brick_picture.get_rect(topleft=(x, y))

    Brick_picture = pygame.transform.scale(pygame.image.load('Images/Brick.png'), (32, 32))
    Rectangle = -1
    Can_destroy = True
    X = -1
    Y = -1

    life = 5

    def Print(self, surface):
        surface.blit(self.Brick_picture, (self.X, self.Y))


class Brick_midle_bloc:
    def __init__(self, x, y, dir):
        if dir == "v":
            self.Brick_picture = pygame.transform.scale(pygame.image.load('Images/BricMidleCub1.png'), (16, 32))
        else:
            self.Brick_picture = pygame.transform.scale(pygame.image.load('Images/BricMidleCub2.png'), (32, 16))
        self.X = x
        self.Y = y
        self.Rectangle = self.Brick_picture.get_rect(topleft=(x, y))


    Brick_picture = -1
    Rectangle = -1
    Can_destroy = True
    X = -1
    Y = -1

    life = 5

    def Print(self, surface):
        surface.blit(self.Brick_picture, (self.X, self.Y))